# UsefulAPI connector plugin

This plugin adds one hosted UsefulAPI MCP server to Claude Code. The server URL comes from the marketplace entry.

After you install the plugin, run `/mcp` in Claude Code and sign in to the server.
The free plan includes 50 tool calls a month. Plans and terms: https://usefulapi.io
